package ERD.ERD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErdApplicationTests {

	@Test
	void contextLoads() {
	}

}
