package ERD.ERD.model;

public enum Status {
    //미확인
    UNCONFIRMED,
    //확인
    CONFIRM,
    //수락
    ACCEPT,
    //거절
    REJECT;
}
