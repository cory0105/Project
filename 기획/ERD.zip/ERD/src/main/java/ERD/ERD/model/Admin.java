package ERD.ERD.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
@Table(name="admin")
public class Admin {
    @Id
    @Column(name="admin_id")
    private String adminId;
    @Column(name="password")
    private String password;
    @Column(name="admin_name")
    private String adminName;
    @Column(name="email")
    private String email;
    @Column(name = "birthday")
    private LocalDateTime birthday;
    @ManyToOne
    @JoinColumn(name = "user_authority")
    private Authority authority;
}
