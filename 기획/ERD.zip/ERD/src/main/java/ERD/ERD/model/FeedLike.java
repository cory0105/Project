package ERD.ERD.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
@Table(name="feed_like")
public class FeedLike {
    @Id
    @ManyToOne
    @JoinColumn(name = "feed_id")
    private Feed feed;
    @Id
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}
