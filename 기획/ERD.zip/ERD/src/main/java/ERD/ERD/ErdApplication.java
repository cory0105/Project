package ERD.ERD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErdApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErdApplication.class, args);
	}

}
