package ERD.ERD.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
@Table(name="training")
public class Training {
    @Id
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    @Id
    @ManyToOne
    @JoinColumn(name = "teacher_id")
    private Teacher teacher;
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    @Column(name = "status")
    private String status;
    @Column(name = "teacher_rating")
    private int teacherRating;
    @Column(name = "teacher_review")
    private String teacherReview;
}
