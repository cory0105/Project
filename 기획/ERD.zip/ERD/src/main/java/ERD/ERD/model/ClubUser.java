package ERD.ERD.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
@Table(name="club_user")
public class ClubUser {
    @Id
    @ManyToOne
    @JoinColumn(name = "group_id")
    private Club club;
    @Id
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    @Column(name = "status")
    private boolean status;
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
