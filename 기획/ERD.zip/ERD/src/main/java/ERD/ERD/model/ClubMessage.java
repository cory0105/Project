package ERD.ERD.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Entity
@Table(name="club_message")
public class ClubMessage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @ManyToOne
    @JoinColumn(name = "group_id")
    private Club club;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    @Column
    private String text;
    @Column
    private String image;
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
