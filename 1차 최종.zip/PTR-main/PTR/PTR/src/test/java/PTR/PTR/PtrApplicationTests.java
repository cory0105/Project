package PTR.PTR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PtrApplicationTests {

	@Test
	void contextLoads() {
	}

}
